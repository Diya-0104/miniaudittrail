# Mini Audit Trail Generator

**Quick summary:** This is a small Next.js app (React + Next API routes) that allows a user to edit text in a content editor and save versions. Each saved version records a small audit-trail entry with a UUID, timestamp, addedWords, removedWords, oldLength, and newLength.

## Features implemented
- Single-page UI (React / Next.js) with a textarea, "Save Version" button, and "Version History" list.
- Backend API routes implemented in Next.js:
  - `POST /api/save-version` — saves a new version, computes diff against previous saved content.
  - `GET /api/versions` — returns all saved versions.
- Custom diff logic (no libraries used) to compute added and removed words using word counts (multisets).
- Simple file-based storage: `data/versions.json` (persisted between server runs in this workspace).
- Uses `uuid` for IDs and ISO-like timestamp in `YYYY-MM-DD HH:mm` format.
- Clean folder structure and comments in code.

## Run locally
1. Install dependencies: `npm install`
2. Run dev server: `npm run dev`
3. Open `http://localhost:3000` in your browser.

## Notes / Limitations
- For the 2-hour task, storage is a JSON file. For production, migrate to a database (SQLite / Postgres).
- The diff algorithm is simple: it tokenizes words by whitespace, strips basic punctuation, and compares counts to find added/removed words.
- API endpoints are in `pages/api`. If deploying to Vercel, this structure works out of the box.

---
Below is the project content. You can unzip and run it.
